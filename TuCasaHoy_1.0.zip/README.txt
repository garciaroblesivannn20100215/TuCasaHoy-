dejarlo en la siguiente ruta:

C:\Users\USUARIO\AndroidStudioProjects\prueba2
(el prueba2 de este .zip)