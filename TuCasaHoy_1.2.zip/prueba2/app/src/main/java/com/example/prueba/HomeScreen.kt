package com.example.prueba

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------- Modelo de datos ----------
data class Propiedad(
    val id: Int,
    val precio: Int,
    val recamaras: Int,
    val banos: Int,
    val imagen: Int
)

// ---------- Pantalla principal ----------
@Composable
fun PantallaPrincipal() {
    val propiedades = remember {
        List(6) { Propiedad(it, 12000, 3, 2, R.drawable.ic_launcher_foreground) }
    }
    val filtros = listOf("Casas", "Lotes/terrenos", "Localidad", "Filtros")
    var mostrarContacto by remember { mutableStateOf(true) }

    Scaffold(
        containerColor = Color.White,
        bottomBar = { BarraInferior() }
    ) { padding ->
        Box(
            Modifier
                .padding(padding)
                .fillMaxSize()
        ) {
            Column(Modifier.fillMaxSize()) {
                BarraBusqueda()
                FiltrosRow(filtros)
                Spacer(Modifier.height(16.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(propiedades) { p ->
                        TarjetaPropiedad(p, onClick = { mostrarContacto = !mostrarContacto })
                    }
                }
            }

            if (mostrarContacto) {
                TarjetaContacto(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 8.dp, bottom = 12.dp)
                )
            }
        }
    }
}

// ---------- Barra de búsqueda ----------
@Composable
fun BarraBusqueda() {
    var texto by remember { mutableStateOf("") }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Menu, contentDescription = "Menú")
        Spacer(Modifier.width(16.dp))
        TextField(
            value = texto,
            onValueChange = { texto = it },
            placeholder = { Text("Buscar", color = Color.Gray) },
            singleLine = true,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent
            ),
            modifier = Modifier.weight(1f)
        )
        Icon(Icons.Default.Search, contentDescription = "Buscar")
    }
}

// ---------- Chips de filtros ----------
@Composable
fun FiltrosRow(filtros: List<String>) {
    var seleccionado by remember { mutableStateOf<String?>(null) }
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(filtros) { filtro ->
            FilterChip(
                selected = seleccionado == filtro,
                onClick = { seleccionado = if (seleccionado == filtro) null else filtro },
                label = { Text(filtro, fontSize = 13.sp) },
                shape = RoundedCornerShape(10.dp),
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = Color.White,
                    selectedContainerColor = Color(0xFFE0E0E0)
                ),
                border = BorderStroke(1.dp, Color(0xFFBDBDBD))
            )
        }
    }
}

// ---------- Tarjeta de propiedad ----------
@Composable
fun TarjetaPropiedad(propiedad: Propiedad, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE0E0E0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Image(
            painter = painterResource(propiedad.imagen),
            contentDescription = "Foto de la propiedad",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
        )
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = buildAnnotatedString {
                        withStyle(SpanStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold)) { append("$") }
                        withStyle(SpanStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold)) {
                            append("%,d".format(propiedad.precio))
                        }
                        withStyle(SpanStyle(fontSize = 12.sp)) { append("/mes") }
                    }
                )
                Icon(
                    Icons.Outlined.FavoriteBorder,
                    contentDescription = "Favorito",
                    modifier = Modifier.size(16.dp)
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "${propiedad.recamaras} rec | ${propiedad.banos} baños",
                    fontSize = 12.sp,
                    color = Color.DarkGray
                )
                Icon(
                    Icons.Default.Share,
                    contentDescription = "Ampliar",
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

// ---------- Globo de contacto ----------
@Composable
fun TarjetaContacto(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(24.dp),
        color = Color.White,
        shadowElevation = 8.dp
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp)) {
            Text("+52 686 568 1130", fontSize = 13.sp)
            Text("+52 686 568 2455", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                Text("Ubicación", fontSize = 11.sp, color = Color.Gray)
                Icon(Icons.Default.LocationOn, contentDescription = "Mapa", modifier = Modifier.size(26.dp))
            }
        }
    }
}

// ---------- Barra de navegación inferior ----------
@Composable
fun BarraInferior() {
    var seleccion by remember { mutableIntStateOf(0) }
    val items = listOf(
        Icons.Default.Home to "Inicio",
        Icons.Default.Notifications to "Avisos",
        Icons.Default.Person to "Perfil",
        Icons.Default.Email to "Chat"
    )
    NavigationBar(containerColor = Color.White) {
        items.forEachIndexed { i, (icono, nombre) ->
            NavigationBarItem(
                selected = seleccion == i,
                onClick = { seleccion = i },
                icon = { Icon(icono, contentDescription = nombre) },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = Color(0xFFE0E0E0)
                )
            )
        }
    }
}

// ---------- Vista previa para Android Studio ----------
@Preview(showBackground = true)
@Composable
fun PantallaPrincipalPreview() {
    MaterialTheme {
        PantallaPrincipal()
    }
}