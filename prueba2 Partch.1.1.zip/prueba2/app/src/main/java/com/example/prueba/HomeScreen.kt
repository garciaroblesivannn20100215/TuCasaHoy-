package com.example.prueba

import android.graphics.drawable.Icon
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Arrangement.SpaceEvenly
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.prueba.ui.theme.PruebaTheme

@Composable
fun HomeScreen(
    modifier: Modifier = Modifier, ) {
    val context = LocalContext.current

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        // Botón grande del centro (el que ya tenías)
        Button(
            onClick = {
                Toast.makeText(context, "¡Hiciste clic en Hola!", Toast.LENGTH_LONG).show()
            },
            shape = CircleShape,
            modifier = Modifier.size(150.dp)
        ) {
            Text(text = "hola", style = MaterialTheme.typography.headlineMedium)
        }

        // Los 4 botones de abajo
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)   // los manda abajo en medio
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly   // mismo espacio entre ellos
        ) {
            Button(
                onClick = { Toast.makeText(context, "Botón 1", Toast.LENGTH_SHORT).show() },
                shape = CircleShape,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(64.dp)
            ) { Icon(Icons.Default.Home, contentDescription = "Inicio") }

            Button(
                onClick = { Toast.makeText(context, "Botón 2", Toast.LENGTH_SHORT).show() },
                shape = CircleShape,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(64.dp)
            ) { Icon(Icons.Default.Search, contentDescription = "Buscar") }

            Button(
                onClick = { Toast.makeText(context, "Botón 3", Toast.LENGTH_SHORT).show() },
                shape = CircleShape,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(64.dp)
            ) { Icon(Icons.Default.Favorite, contentDescription = "Favoritos") }

            Button(
                onClick = { Toast.makeText(context, "Botón 4", Toast.LENGTH_SHORT).show() },
                shape = CircleShape,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(64.dp)
            ) { Icon(Icons.Default.Person, contentDescription = "Perfil") }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    PruebaTheme {
        HomeScreen()
    }
}
